import json
import requests
import csv
# install requests by runing 'pip3 install requests'


baseAuthUrl = '' #ex: https://auth.qa.flowxai.dev
username = ''
password = ''
realm = '' #ex flowxai
superAdminGroupName = ''

def loadCSVFromFile(fileName):
    listOfRoles = []
    with open('roles.csv', mode='r') as inp:
        reader = csv.reader(inp)
        for rows in reader:
            roleDictionary = {}
            roleDictionary["name"] = rows[0]
            roleDictionary["description"] = rows[1]
            listOfRoles.append(roleDictionary)
    return listOfRoles


def login(session):
    print("Starting Login")
    customHeaders = {'content_type' : 'application/x-www-form-urlencoded'}
    response = requests.post(baseAuthUrl + '/auth/realms/master/protocol/openid-connect/token', data = {'grant_type':'password', 'username': username, 'password': password, 'client_id':'admin-cli'}, headers = customHeaders)
    access_token = response.json()["access_token"]
    session.headers.update({'Authorization': 'Bearer ' + access_token})
    if response.status_code == 200:
        print("Login with token:" + access_token)
    else:
        print(response.json())

def deleteUserRole(role, session):
    print("Deleteing role:" + role["name"])
    customHeaders = {'content_type' : 'application/json'}
    response = session.delete(baseAuthUrl + '/auth/admin/realms/' + realm + '/roles/' + role["name"], headers = customHeaders)
    if response.status_code == 204:
        print("Response of deleteing: " + role["name"] + " ->" + str(response.status_code))
    else:
        print(response.json())   

def createUserRole(role, session):
    print("Creating role:" + role["name"])
    customHeaders = {'content_type' : 'application/json'}
    response = session.post(baseAuthUrl + '/auth/admin/realms/' + realm + '/roles', json = {"name": role["name"], "description": role["description"]}, headers = customHeaders)
    if response.status_code == 201:
        print("Response of creating: " + role["name"] + " ->" + str(response.status_code))
    else:
        print(response.json())  

def createUserGroup(group, session):
    print("Craete group:" + group)
    customHeaders = {'content_type' : 'application/json'}
    response = session.post(baseAuthUrl + '/auth/admin/realms/' + realm + '/groups', json = {"name": group}, headers = customHeaders)
    if response.status_code == 201:
        print("Response of creating: " + group + " ->" + str(response.status_code))
    else:
        print(response.json())  

def getRoleId(role, session):
    print("Get Id of role:" + role["name"])
    customHeaders = {'content_type' : 'application/json'}
    response = session.get(baseAuthUrl + '/auth/admin/realms/' + realm + '/roles', headers = customHeaders)
    id = ''
    for roleObject in response.json():
        if roleObject["name"] == role["name"]:
            id = roleObject["id"]
            break
    print("Found role " + role["name"] + " with id: " + id)
    return id

def getGroupId(group, session):
    print("Get Id of group:" + group)
    customHeaders = {'content_type' : 'application/json'}
    response = session.get(baseAuthUrl + '/auth/admin/realms/' + realm + '/groups', headers = customHeaders)
    id = ''
    for groupObject in response.json():
        if groupObject["name"] == group:
            id = groupObject["id"]
            break
    print("Found group " + group + " with id: " + id)
    return id

def linkRoleWithGroup(role, roleId, groupId, session):
    print("Adding role:" + role["name"] + " with id:" + roleId + " in groupId:" + groupId)
    customHeaders = {'content_type' : 'application/json'}
    response = session.post(baseAuthUrl + '/auth/admin/realms/' + realm + '/groups/' + groupId + "/role-mappings/realm", json = [{'name': role["name"], 'id': roleId}], headers = customHeaders)
    if response.status_code == 204:
        print("Response of creating: " + role["name"] + " in group id:" + groupId + " ->" + str(response.status_code))
    else:
        print(response.json())


session = requests.Session()
print("Start")
roles = loadCSVFromFile("roles.csv")
print(roles)
login(session)
createUserGroup(superAdminGroupName, session)
groupId = getGroupId(superAdminGroupName, session)
for role in roles:
    deleteUserRole(role, session)
    createUserRole(role, session)
    roleId = getRoleId(role, session)
    linkRoleWithGroup(role, roleId, groupId, session)
print("Finish")